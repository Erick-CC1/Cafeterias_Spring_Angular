export class Administrador {
    id:number;
    contrasena:string;
    nombre_usuario:string;
}
