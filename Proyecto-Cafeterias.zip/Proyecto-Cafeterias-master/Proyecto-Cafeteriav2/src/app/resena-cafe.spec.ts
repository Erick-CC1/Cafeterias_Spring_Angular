import { ResenaCafe } from './resena-cafe';

describe('ResenaCafe', () => {
  it('should create an instance', () => {
    expect(new ResenaCafe()).toBeTruthy();
  });
});
