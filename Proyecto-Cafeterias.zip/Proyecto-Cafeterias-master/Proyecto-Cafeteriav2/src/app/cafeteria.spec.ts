import { Cafeteria } from './cafeteria';

describe('Cafeteria', () => {
  it('should create an instance', () => {
    expect(new Cafeteria()).toBeTruthy();
  });
});
