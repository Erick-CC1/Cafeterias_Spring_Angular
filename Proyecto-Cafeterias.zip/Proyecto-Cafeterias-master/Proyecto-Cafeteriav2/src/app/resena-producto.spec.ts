import { ResenaProducto } from './resena-producto';

describe('ResenaProducto', () => {
  it('should create an instance', () => {
    expect(new ResenaProducto()).toBeTruthy();
  });
});
