export class Cafeteria {
    
    id:number;
    calificacionPromedio:Float32List;
    descripcion:string;
    direccion:string;
    nombre:string;
    imagen:string;


  

}
