export class Usuario {
    id:number;
    contrasena:string;
    correoElectronico:string;
    nombre:string;
    tipo:string
}
